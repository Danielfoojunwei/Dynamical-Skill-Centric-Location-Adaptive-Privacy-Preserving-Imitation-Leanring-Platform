"""
Dynamical Edge System Version
"""

__version__ = "0.1.0"
__author__ = "Dynamical Robotics"
__status__ = "Production Prototype"

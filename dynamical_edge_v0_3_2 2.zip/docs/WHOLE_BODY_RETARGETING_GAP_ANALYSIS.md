# Whole-Body Retargeting Gap Analysis

## MMPose + GMR Integration Assessment

**Date:** December 2025  
**Files Analyzed:**
- `src/core/whole_body_gmr.py` (451 lines)
- `src/core/wholebody_pose_pipeline.py` (1254 lines)
- `src/core/retargeting.py` (999 lines)
- `src/core/human_state.py` (312 lines)
- `src/core/hand_retargeting.py` (new, 780 lines)
- `src/platform/calibration/mmpose_calibration.py` (1484 lines)

---

## Executive Summary

The implementation has a **good architectural foundation** but is missing several critical components for production deployment. The current state is approximately **65% complete** for a functional whole-body retargeting system.

### Key Findings

| Component | Status | Completeness |
|-----------|--------|--------------|
| COCO-WholeBody 133 keypoint definitions | ✅ Done | 100% |
| 2D Pose estimation abstraction | ✅ Done | 90% |
| Multi-view triangulation | ✅ Done | 85% |
| Quality scoring | ✅ Done | 80% |
| GMR wrapper | ⚠️ Partial | 60% |
| **Real model inference** | ❌ Missing | 10% |
| **DeepStream integration** | ❌ Missing | 0% |
| **Camera sync** | ❌ Missing | 20% |
| **Body-glove calibration** | ⚠️ Partial | 40% |
| **SMPL body model** | ❌ Missing | 0% |
| **IK solver integration** | ⚠️ Partial | 30% |

---

## Critical Gaps (P0)

### 1. No Real RTMPose/RTMW3D Model Inference

**Current State:**
```python
# In wholebody_pose_pipeline.py line 306-320
def infer(self, image: np.ndarray, camera_id: str = "cam0") -> Pose2DResult:
    if not self._initialized:
        return self._mock_inference(...)  # Always returns mock data!
    # Real inference would go here - NOT IMPLEMENTED
    return self._mock_inference(...)
```

**Missing:**
- Actual ONNX model loading
- TensorRT engine compilation
- Pre/post-processing pipelines
- Person detection (YOLO/RTMDet)

**Required Implementation:**
```python
class RTMPoseRealInference(RTMPoseInference):
    def __init__(self, config: PoseEstimationConfig):
        self.det_model = self._load_detector()  # RTMDet or YOLOv8
        self.pose_model = self._load_pose_model()  # RTMPose
        
    def _load_pose_model(self):
        import onnxruntime as ort
        # Need actual model file: rtmpose-l_8xb256-420e_coco-wholebody-256x192.onnx
        session_options = ort.SessionOptions()
        if "tensorrt" in self.config.backend:
            providers = [('TensorrtExecutionProvider', {
                'trt_fp16_enable': True,
                'trt_engine_cache_enable': True,
            })]
        return ort.InferenceSession(self.config.model_path, providers=providers)
    
    def infer(self, image: np.ndarray) -> Pose2DResult:
        # 1. Detect persons
        bboxes = self.det_model(image)
        
        # 2. Crop and preprocess each person
        crops = [self._crop_person(image, bbox) for bbox in bboxes]
        
        # 3. Run pose estimation
        keypoints = self.pose_model.run(None, {'input': np.stack(crops)})[0]
        
        # 4. Post-process (flip back, scale to original)
        return self._postprocess(keypoints, bboxes)
```

**Effort:** ~3-4 days

---

### 2. No GMR Library Integration

**Current State:**
```python
# In whole_body_gmr.py line 303-326
def _init_gmr(self):
    try:
        from gmr import GeneralMotionRetargeting  # DOES NOT EXIST
        ...
    except ImportError:
        self.gmr = MockGMRRetargeter(...)  # Always uses mock!
```

**Problem:** GMR library (`github.com/YanjieZe/GMR`) has no Python package. Need to either:
1. Build GMR from source and create Python bindings
2. Implement core retargeting algorithm natively

**Missing:**
- URDF loading and parsing
- Forward kinematics computation
- Inverse kinematics solver
- Kinematic chain mapping (human → robot)
- Joint limit enforcement

**Required Implementation:**
```python
class GMRNativeRetargeter:
    """Native implementation of GMR-style retargeting."""
    
    def __init__(self, urdf_path: str):
        import yourdfpy  # or urdfpy
        self.robot = yourdfpy.URDF.load(urdf_path)
        self.chain = self._build_kinematic_chain()
        
    def retarget(self, human_positions: np.ndarray, confidence: np.ndarray) -> np.ndarray:
        # 1. Compute human joint angles from positions
        human_angles = self._positions_to_angles(human_positions)
        
        # 2. Map to robot joint space
        robot_angles = self._apply_joint_mapping(human_angles)
        
        # 3. Solve IK for end-effector matching
        robot_angles = self._refine_with_ik(robot_angles, human_positions)
        
        # 4. Apply limits and smoothing
        return self._clamp_and_smooth(robot_angles)
```

**Effort:** ~5-7 days

---

### 3. Missing DeepStream/TensorRT Integration

**Current State:** ONNX Runtime used, no DeepStream for multi-stream.

**Missing:**
- GStreamer pipeline construction
- NvInfer plugin configuration
- Multi-stream batching
- GPU memory management
- INT8 calibration support

**Required for Production:**
```python
class DeepStreamPosePipeline:
    """DeepStream 6.x multi-camera pose pipeline."""
    
    def __init__(self, num_cameras: int, model_config: str):
        import pyds
        import gi
        gi.require_version('Gst', '1.0')
        from gi.repository import Gst
        
        self.pipeline = self._create_pipeline(num_cameras)
        self.num_cameras = num_cameras
        
    def _create_pipeline(self, num_cameras: int) -> Gst.Pipeline:
        # nvstreammux → nvinfer (detection) → nvinfer (pose) → nvstreamdemux
        pipeline_str = f"""
            nvstreammux name=mux batch-size={num_cameras} width=1920 height=1080 !
            nvinfer config-file-path=config_det.txt !
            nvinfer config-file-path=config_pose.txt !
            nvstreamdemux name=demux
        """
        # Add sources for each camera
        for i in range(num_cameras):
            pipeline_str = f"nvv4l2camerasrc device=/dev/video{i} ! mux.sink_{i} " + pipeline_str
```

**Effort:** ~4-5 days

---

### 4. Incomplete Body-Glove Fusion Calibration

**Current State:**
```python
# In wholebody_pose_pipeline.py line 938-1000
class BodyGloveFusion:
    def __init__(self):
        self.T_world_imu_left: Optional[np.ndarray] = None  # Not calibrated!
        self.T_world_imu_right: Optional[np.ndarray] = None
```

**Missing:**
- Automatic calibration procedure
- IMU → world frame estimation
- Temporal alignment (glove vs camera timestamps)
- Occlusion handling (glove continues when camera loses tracking)

**Required Implementation:**
```python
class BodyGloveCalibrator:
    """Calibrate IMU→World transform for glove."""
    
    def calibrate(self, duration_sec: float = 10.0) -> np.ndarray:
        """
        Calibration procedure:
        1. User moves hand in 8-pattern (covers all orientations)
        2. Record camera wrist poses and glove IMU orientations
        3. Solve Procrustes alignment to find T_world_imu
        """
        samples = []
        
        start = time.time()
        while time.time() - start < duration_sec:
            # Get camera wrist orientation (from arm direction)
            R_camera = self._estimate_wrist_rotation_from_arm()
            
            # Get glove IMU orientation
            R_imu = glove.get_orientation_matrix()
            
            samples.append((R_camera, R_imu))
        
        # Solve: R_camera = T_world_imu @ R_imu for all samples
        return self._solve_procrustes(samples)
```

**Effort:** ~2-3 days

---

## Major Gaps (P1)

### 5. No SMPL Body Model Integration

**Why Needed:**
- GMR and many retargeting methods use SMPL/SMPL-X as intermediate representation
- Provides consistent body topology across different humans
- Enables mesh-based rendering for visualization
- Required for accurate physics simulation

**Current State:** Only 22-joint skeleton, no SMPL.

**Required Implementation:**
```python
class SMPLBodyModel:
    """SMPL body model for retargeting."""
    
    def __init__(self, model_path: str = "models/smpl/SMPL_NEUTRAL.pkl"):
        import smplx
        self.model = smplx.SMPL(model_path)
        
    def fit_to_keypoints(self, keypoints_3d: np.ndarray) -> dict:
        """Fit SMPL parameters to 3D keypoints."""
        # Optimization to find pose (72D) and shape (10D) params
        return {
            'body_pose': np.zeros(72),
            'betas': np.zeros(10),
            'global_orient': np.zeros(3),
            'transl': np.zeros(3),
        }
    
    def get_joints(self, params: dict) -> np.ndarray:
        """Get SMPL joint positions from parameters."""
        output = self.model(**params)
        return output.joints.numpy()
```

**Effort:** ~3-4 days

---

### 6. Missing Multi-Camera Synchronization

**Current State:** No hardware sync, assumes software sync.

**Problem:** Without sync, triangulation errors increase significantly:
- 33ms desync @ 30fps → 3-5cm position error for fast motions
- Industrial teleoperation requires <10ms sync

**Required Implementation:**
```python
class HardwareSyncManager:
    """Hardware-triggered multi-camera sync."""
    
    def __init__(self, cameras: List[Camera], trigger_gpio: int = 12):
        self.cameras = cameras
        self.trigger = GPIO(trigger_gpio, GPIO.OUT)
        
    def capture_synchronized(self) -> Dict[str, Tuple[np.ndarray, float]]:
        """Capture from all cameras with hardware trigger."""
        # 1. Arm all cameras
        for cam in self.cameras:
            cam.arm_trigger()
        
        # 2. Fire hardware trigger (GPIO pulse)
        self.trigger.pulse(width_us=100)
        
        # 3. Collect frames with precise timestamps
        frames = {}
        for cam in self.cameras:
            frame, timestamp = cam.retrieve_triggered()
            frames[cam.id] = (frame, timestamp)
        
        return frames
```

For software sync (fallback):
```python
class SoftwareSyncManager:
    """PTP/NTP-based software sync with timestamp interpolation."""
    
    def synchronize_poses(
        self,
        poses: Dict[str, List[Pose2DResult]],  # Per-camera history
        target_time: float,
    ) -> Dict[str, Pose2DResult]:
        """Interpolate poses to common timestamp."""
        synced = {}
        for cam_id, history in poses.items():
            # Find bracketing frames
            before = [p for p in history if p.timestamp <= target_time][-1]
            after = [p for p in history if p.timestamp > target_time][0]
            
            # Linear interpolation
            alpha = (target_time - before.timestamp) / (after.timestamp - before.timestamp)
            synced[cam_id] = self._interpolate_pose(before, after, alpha)
        
        return synced
```

**Effort:** ~3-4 days

---

### 7. Missing IK Solver Integration

**Current State:** Placeholder IK in `retargeting.py` with simple numerical Jacobian.

**Problem:** 
- No real robot URDF loading
- No collision checking
- No joint limit handling
- Slow convergence

**Required Implementation:**
```python
class PinocchioIKSolver:
    """Production IK solver using Pinocchio."""
    
    def __init__(self, urdf_path: str):
        import pinocchio as pin
        self.model = pin.buildModelFromUrdf(urdf_path)
        self.data = self.model.createData()
        
    def solve(
        self,
        q_init: np.ndarray,
        T_ee_target: np.ndarray,
        ee_frame: str = "ee_link",
    ) -> Tuple[np.ndarray, bool, float]:
        """Solve IK using Pinocchio's CLIK algorithm."""
        import pinocchio as pin
        
        frame_id = self.model.getFrameId(ee_frame)
        
        q = q_init.copy()
        for i in range(100):
            pin.forwardKinematics(self.model, self.data, q)
            pin.updateFramePlacement(self.model, self.data, frame_id)
            
            T_current = self.data.oMf[frame_id]
            err = pin.log6(T_current.inverse() * pin.SE3(T_ee_target))
            
            if np.linalg.norm(err.vector) < 1e-4:
                return q, True, np.linalg.norm(err.vector)
            
            J = pin.computeFrameJacobian(self.model, self.data, q, frame_id)
            dq = np.linalg.pinv(J) @ err.vector
            q = pin.integrate(self.model, q, dq)
        
        return q, False, np.linalg.norm(err.vector)
```

**Effort:** ~2-3 days

---

## Minor Gaps (P2)

### 8. Missing Pose Filtering/Tracking

- No Kalman filter for jitter reduction
- No track-by-detection (multi-person tracking)
- No occlusion prediction

### 9. No Latency Monitoring

- No end-to-end latency measurement
- No frame drop detection
- No performance profiling

### 10. Missing Visualization Tools

- No real-time skeleton overlay
- No 3D scene visualization
- No reprojection error display

---

## Implementation Roadmap

### Phase 1: Core Inference (Week 1)
1. ✅ Download RTMPose ONNX models
2. Implement `RTMPoseRealInference` class
3. Add person detection (YOLOv8 or RTMDet)
4. Test on single camera

### Phase 2: Multi-Camera (Week 2)
1. Implement camera synchronization
2. Improve triangulation with RANSAC
3. Add pose filtering (Kalman)
4. Test with 4 cameras

### Phase 3: GMR Integration (Week 3)
1. Implement native retargeting algorithm
2. Add URDF loading (yourdfpy/urdfpy)
3. Integrate Pinocchio IK solver
4. Add joint mapping for target robots

### Phase 4: Body-Glove Fusion (Week 4)
1. Implement calibration procedure
2. Add temporal alignment
3. Integrate 21-DOF hand with body
4. Test full teleoperation loop

### Phase 5: Production Hardening (Week 5)
1. Add DeepStream integration
2. Implement latency monitoring
3. Add visualization tools
4. Performance optimization

---

## Files to Create/Modify

### New Files Needed:

| File | Purpose | Size Est. |
|------|---------|-----------|
| `src/core/rtmpose_inference.py` | Real model inference | ~500 lines |
| `src/core/deepstream_pose.py` | DeepStream pipeline | ~400 lines |
| `src/core/gmr_native.py` | Native GMR implementation | ~800 lines |
| `src/core/smpl_model.py` | SMPL body model | ~300 lines |
| `src/core/pinocchio_ik.py` | IK solver wrapper | ~250 lines |
| `src/core/multi_cam_sync.py` | Camera synchronization | ~300 lines |
| `src/core/pose_tracker.py` | Kalman filter + tracking | ~400 lines |

### Existing Files to Modify:

| File | Changes |
|------|---------|
| `wholebody_pose_pipeline.py` | Replace mock inference, add sync |
| `whole_body_gmr.py` | Integrate native GMR |
| `retargeting.py` | Add Pinocchio IK |
| `hand_retargeting.py` | Improve body-hand fusion |

---

## Model Files Required

| Model | Size | Source |
|-------|------|--------|
| `rtmpose-l-wholebody.onnx` | ~250 MB | MMPose Model Zoo |
| `rtmdet-m.onnx` | ~150 MB | MMDetection Model Zoo |
| `SMPL_NEUTRAL.pkl` | ~10 MB | SMPL website |
| Robot URDFs | ~1-10 MB | Manufacturer or URDF repos |

---

## Summary

**Total Implementation Effort:** ~20-25 engineering days

**Priority Order:**
1. **P0:** Real inference, GMR native, DeepStream (12-15 days)
2. **P1:** SMPL, sync, IK solver (8-10 days)
3. **P2:** Filtering, monitoring, visualization (5 days)

**Blocking Dependencies:**
- RTMPose ONNX models (download from MMPose)
- Robot URDFs (obtain from manufacturer)
- Camera hardware sync support (GPIO or PTP)

The architecture is sound; the main work is replacing mock implementations with real ones.
